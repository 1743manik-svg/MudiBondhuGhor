# মুদি বন্ধু ঘর (MudiBondhuGhor)

Offline-first Android starter project using Kotlin, Jetpack Compose and Room.

## Included
- Dashboard with sales, expenses, customer due and product count
- Product entry/list
- Sale entry/list
- Customer entry/list
- Expense entry/list
- Accounts summary
- Room database schema version 2 and a version 1 -> 2 migration
- Money stored as integer paisa to avoid floating-point accounting errors

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

Requirements: Android Studio with JDK 17, Android SDK 35, and internet access for the first Gradle dependency download.

## Important status
This source project has not been compiled or run in this environment. Treat it as a first implementation, not a verified release APK. The current version is a functional foundation: sales are recorded as totals (not itemized stock deductions), and customer/supplier ledger settlement, purchase workflow, backup/restore, and full reporting still need implementation and testing.
