package com.mudibondhu.ghor.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StoreDao {
    @Query("SELECT * FROM products ORDER BY name") fun products(): Flow<List<Product>>
    @Query("SELECT * FROM customers ORDER BY name") fun customers(): Flow<List<Customer>>
    @Query("SELECT * FROM suppliers ORDER BY name") fun suppliers(): Flow<List<Supplier>>
    @Query("SELECT * FROM sales ORDER BY createdAt DESC") fun sales(): Flow<List<Sale>>
    @Query("SELECT * FROM purchases ORDER BY createdAt DESC") fun purchases(): Flow<List<Purchase>>
    @Query("SELECT * FROM expenses ORDER BY createdAt DESC") fun expenses(): Flow<List<Expense>>
    @Query("SELECT COALESCE(SUM(totalPaisa),0) FROM sales") fun salesTotal(): Flow<Long>
    @Query("SELECT COALESCE(SUM(amountPaisa),0) FROM expenses") fun expenseTotal(): Flow<Long>
    @Query("SELECT COALESCE(SUM(balancePaisa),0) FROM customers") fun customerDue(): Flow<Long>
    @Query("SELECT COALESCE(SUM(balancePaisa),0) FROM suppliers") fun supplierDue(): Flow<Long>

    @Insert suspend fun addProduct(item: Product): Long
    @Insert suspend fun addCustomer(item: Customer): Long
    @Insert suspend fun addSupplier(item: Supplier): Long
    @Insert suspend fun addSale(item: Sale): Long
    @Insert suspend fun addPurchase(item: Purchase): Long
    @Insert suspend fun addPayment(item: Payment): Long
    @Insert suspend fun addExpense(item: Expense): Long

    @Query("UPDATE products SET stockMilli = stockMilli + :quantityMilli WHERE id = :id")
    suspend fun changeStock(id: Long, quantityMilli: Long)
    @Query("UPDATE customers SET balancePaisa = balancePaisa + :delta WHERE id = :id")
    suspend fun changeCustomerBalance(id: Long, delta: Long)
    @Query("UPDATE suppliers SET balancePaisa = balancePaisa + :delta WHERE id = :id")
    suspend fun changeSupplierBalance(id: Long, delta: Long)
}
