package com.mudibondhu.ghor.core

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Money {
    fun format(paisa: Long): String {
        val taka = paisa / 100.0
        return "৳" + DecimalFormat("#,##0.00").format(taka)
    }
    fun parseTaka(value: String): Long? = value.trim().replace(",", "").toBigDecimalOrNull()
        ?.multiply(100.toBigDecimal())?.toLong()
}

object BanglaNumber {
    private val digits = "০১২৩৪৫৬৭৮৯"
    fun convert(value: String): String = value.map { if (it in '0'..'9') digits[it - '0'] else it }.joinToString("")
}

object DateFormat {
    fun date(timestamp: Long): String =
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale("bn", "BD")).format(Date(timestamp))
}

object Validators {
    fun nonEmpty(value: String) = value.trim().isNotEmpty()
    fun positiveMoney(value: String): Long? = Money.parseTaka(value)?.takeIf { it > 0 }
}
