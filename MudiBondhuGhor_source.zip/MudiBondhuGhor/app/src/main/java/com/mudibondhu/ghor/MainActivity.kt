package com.mudibondhu.ghor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import com.mudibondhu.ghor.core.Money
import com.mudibondhu.ghor.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent {
            val vm: StoreViewModel = viewModel(factory = StoreViewModel.Factory(db))
            MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF146C43))) {
                StoreApp(vm)
            }
        }
    }
}

class StoreViewModel(private val db: AppDatabase) : ViewModel() {
    private val dao = db.storeDao()
    val products = dao.products().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val customers = dao.customers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val sales = dao.sales().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val expenses = dao.expenses().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val salesTotal = dao.salesTotal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    val expenseTotal = dao.expenseTotal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    val customerDue = dao.customerDue().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    val supplierDue = dao.supplierDue().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    fun addProduct(name: String, unit: String, buy: String, sell: String) = viewModelScope.launch {
        if (name.isBlank()) return@launch
        dao.addProduct(Product(name = name.trim(), unit = unit.ifBlank { "পিস" },
            buyPricePaisa = Money.parseTaka(buy) ?: 0, sellPricePaisa = Money.parseTaka(sell) ?: 0))
    }
    fun addCustomer(name: String, phone: String) = viewModelScope.launch {
        if (name.isNotBlank()) dao.addCustomer(Customer(name = name.trim(), phone = phone.trim()))
    }
    fun addSale(total: String, paid: String, note: String) = viewModelScope.launch {
        val amount = Money.parseTaka(total)?.takeIf { it > 0 } ?: return@launch
        val payment = (Money.parseTaka(paid) ?: 0).coerceIn(0, amount)
        db.withTransaction { dao.addSale(Sale(totalPaisa = amount, paidPaisa = payment, note = note)); }
    }
    fun addExpense(title: String, amountText: String, category: String) = viewModelScope.launch {
        val amount = Money.parseTaka(amountText)?.takeIf { it > 0 } ?: return@launch
        dao.addExpense(Expense(title = title.ifBlank { "অন্যান্য খরচ" }, amountPaisa = amount, category = category))
    }

    class Factory(private val db: AppDatabase) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = StoreViewModel(db) as T
    }
}

private enum class Page(val label: String) {
    HOME("হোম"), PRODUCTS("পণ্য"), SALES("বিক্রি"), CUSTOMERS("বাকি"), EXPENSES("খরচ"), ACCOUNTS("হিসাব")
}

@Composable
fun StoreApp(vm: StoreViewModel) {
    var page by remember { mutableStateOf(Page.HOME) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("মুদি বন্ধু ঘর", fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar {
                listOf(Page.HOME, Page.PRODUCTS, Page.SALES, Page.CUSTOMERS, Page.EXPENSES, Page.ACCOUNTS).forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item },
                        icon = { Icon(when(item) {
                            Page.HOME -> Icons.Default.Home
                            Page.PRODUCTS -> Icons.Default.Inventory2
                            Page.SALES -> Icons.Default.PointOfSale
                            Page.CUSTOMERS -> Icons.Default.People
                            Page.EXPENSES -> Icons.Default.ReceiptLong
                            Page.ACCOUNTS -> Icons.Default.AccountBalance
                        }, contentDescription = item.label) }, label = { Text(item.label) })
                }
            }
        }
    ) { padding ->
        when(page) {
            Page.HOME -> HomeScreen(vm, Modifier.padding(padding))
            Page.PRODUCTS -> ProductsScreen(vm, Modifier.padding(padding))
            Page.SALES -> SalesScreen(vm, Modifier.padding(padding))
            Page.CUSTOMERS -> CustomersScreen(vm, Modifier.padding(padding))
            Page.EXPENSES -> ExpensesScreen(vm, Modifier.padding(padding))
            Page.ACCOUNTS -> AccountsScreen(vm, Modifier.padding(padding))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen(vm: StoreViewModel, modifier: Modifier = Modifier) {
    val sales by vm.salesTotal.collectAsState()
    val expense by vm.expenseTotal.collectAsState()
    val due by vm.customerDue.collectAsState()
    val products by vm.products.collectAsState()
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("আজকের দোকানের সারাংশ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryCard("মোট বিক্রি", Money.format(sales), Modifier.weight(1f))
            SummaryCard("মোট খরচ", Money.format(expense), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryCard("কাস্টমার বাকি", Money.format(due), Modifier.weight(1f))
            SummaryCard("পণ্যের সংখ্যা", products.size.toString(), Modifier.weight(1f))
        }
        Card(shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("শুরু করুন", fontWeight = FontWeight.Bold)
                Text("পণ্য যোগ করুন, বিক্রি লিখুন এবং প্রতিদিনের খরচ সংরক্ষণ করুন।")
                Text("আপনার তথ্য এই ফোনের অফলাইন ডাটাবেজে থাকবে।", color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ProductsScreen(vm: StoreViewModel, modifier: Modifier = Modifier) {
    val products by vm.products.collectAsState()
    var show by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ScreenHeader("পণ্যের তালিকা", "পণ্য যোগ করুন") { show = true }
        if (products.isEmpty()) EmptyHint("এখনো কোনো পণ্য যোগ করা হয়নি")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products) { p ->
                ListCard(p.name, "${p.unit}  •  ক্রয় ${Money.format(p.buyPricePaisa)}  •  বিক্রয় ${Money.format(p.sellPricePaisa)}")
            }
        }
    }
    if (show) ProductDialog({ show = false }) { n,u,b,s -> vm.addProduct(n,u,b,s); show = false }
}

@Composable
private fun SalesScreen(vm: StoreViewModel, modifier: Modifier = Modifier) {
    val sales by vm.sales.collectAsState()
    var show by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ScreenHeader("বিক্রির খাতা", "বিক্রি যোগ করুন") { show = true }
        if (sales.isEmpty()) EmptyHint("এখনো কোনো বিক্রি লেখা হয়নি")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sales) { s -> ListCard("বিক্রি ${s.id}", "মোট ${Money.format(s.totalPaisa)} • জমা ${Money.format(s.paidPaisa)} • বাকি ${Money.format(s.totalPaisa-s.paidPaisa)}") }
        }
    }
    if (show) SaleDialog({ show = false }) { t,p,n -> vm.addSale(t,p,n); show = false }
}

@Composable
private fun CustomersScreen(vm: StoreViewModel, modifier: Modifier = Modifier) {
    val customers by vm.customers.collectAsState()
    var show by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ScreenHeader("কাস্টমার ও বাকি", "কাস্টমার যোগ করুন") { show = true }
        if (customers.isEmpty()) EmptyHint("কাস্টমার যোগ করলে এখানে দেখা যাবে")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(customers) { c -> ListCard(c.name, "${c.phone} • বাকি ${Money.format(c.balancePaisa)}") }
        }
    }
    if (show) CustomerDialog({ show = false }) { n,p -> vm.addCustomer(n,p); show = false }
}

@Composable
private fun ExpensesScreen(vm: StoreViewModel, modifier: Modifier = Modifier) {
    val expenses by vm.expenses.collectAsState()
    var show by remember { mutableStateOf(false) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        ScreenHeader("দৈনিক খরচ", "খরচ যোগ করুন") { show = true }
        if (expenses.isEmpty()) EmptyHint("এখনো কোনো খরচ লেখা হয়নি")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(expenses) { e -> ListCard(e.title, "${e.category} • ${Money.format(e.amountPaisa)}") }
        }
    }
    if (show) ExpenseDialog({ show = false }) { n,a,c -> vm.addExpense(n,a,c); show = false }
}

@Composable
private fun AccountsScreen(vm: StoreViewModel, modifier: Modifier = Modifier) {
    val sales by vm.salesTotal.collectAsState()
    val expenses by vm.expenseTotal.collectAsState()
    val customerDue by vm.customerDue.collectAsState()
    val supplierDue by vm.supplierDue.collectAsState()
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("হিসাবের সারাংশ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SummaryCard("মোট বিক্রি", Money.format(sales))
        SummaryCard("মোট খরচ", Money.format(expenses))
        SummaryCard("কাস্টমারের কাছে পাওনা", Money.format(customerDue))
        SummaryCard("সাপ্লায়ারকে দেনা", Money.format(supplierDue))
        Text("নোট: এই সংস্করণে সারাংশ ও প্রাথমিক এন্ট্রি চালু আছে। পূর্ণ লেনদেন-ভিত্তিক বাকি সমন্বয় পরবর্তী সংস্করণে যোগ করতে হবে।", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ScreenHeader(title: String, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Button(onClick = onClick) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text(action) }
    }
    Spacer(Modifier.height(12.dp))
}
@Composable private fun EmptyHint(text: String) { Text(text, Modifier.fillMaxWidth().padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
@Composable private fun ListCard(title: String, detail: String) {
    Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) { Text(title, fontWeight = FontWeight.SemiBold); Text(detail, style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable
private fun ProductDialog(onDismiss: () -> Unit, onSave: (String,String,String,String) -> Unit) {
    var name by remember { mutableStateOf("") }; var unit by remember { mutableStateOf("পিস") }
    var buy by remember { mutableStateOf("") }; var sell by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("নতুন পণ্য") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(name,{name=it},"পণ্যের নাম"); Field(unit,{unit=it},"একক (পিস/কেজি)")
            Field(buy,{buy=it},"ক্রয় মূল্য (টাকা)", true); Field(sell,{sell=it},"বিক্রয় মূল্য (টাকা)", true)
        }
    }, confirmButton = { TextButton(onClick = { onSave(name,unit,buy,sell) }) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}
@Composable
private fun SaleDialog(onDismiss: () -> Unit, onSave: (String,String,String) -> Unit) {
    var total by remember { mutableStateOf("") }; var paid by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("নতুন বিক্রি") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(total,{total=it},"মোট টাকা",true); Field(paid,{paid=it},"জমা টাকা",true); Field(note,{note=it},"বিবরণ")
        }
    }, confirmButton = { TextButton(onClick = { onSave(total,paid,note) }) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}
@Composable
private fun CustomerDialog(onDismiss: () -> Unit, onSave: (String,String) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("নতুন কাস্টমার") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Field(name,{name=it},"নাম"); Field(phone,{phone=it},"মোবাইল নম্বর",true) }
    }, confirmButton = { TextButton(onClick = { onSave(name,phone) }) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}
@Composable
private fun ExpenseDialog(onDismiss: () -> Unit, onSave: (String,String,String) -> Unit) {
    var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var category by remember { mutableStateOf("দোকান খরচ") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("নতুন খরচ") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Field(title,{title=it},"খরচের নাম"); Field(amount,{amount=it},"টাকা",true); Field(category,{category=it},"ধরন") }
    }, confirmButton = { TextButton(onClick = { onSave(title,amount,category) }) { Text("সংরক্ষণ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}
@Composable
private fun Field(value: String, onChange: (String)->Unit, label: String, number: Boolean = false) {
    OutlinedTextField(value,onChange,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth(),
        keyboardOptions=KeyboardOptions(keyboardType=if(number) KeyboardType.Decimal else KeyboardType.Text))
}
